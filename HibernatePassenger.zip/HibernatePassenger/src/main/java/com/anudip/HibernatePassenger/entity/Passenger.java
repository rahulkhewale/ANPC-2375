package com.anudip.HibernatePassenger.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data // combination of getter setter and constructor
@Entity
@Table(name= "passenger_details")


public class Passenger {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(length = 3)
	private int Pid;
	
	@Min(value =3)
	private String Pname;
	
	@Column(length =50, nullable = false)
	@NotBlank(message = "address cannot blank")
	private String adr;
	
	
	@Column(length =2, nullable = false)
	@NotBlank(message = "passenger age cannot blank")
	@Email(message = "Incorrect age Id")
	private int age;
	
	@Column(length =30, nullable = false, unique = true)
	@NotBlank(message = "passanger phone cannot blank")
	private long phone;
	
	public int getPid() {
		return Pid;
	}

	public void setPid(int pid) {
		Pid = pid;
	}

	

	public String getPname() {
		return Pname;
	}

	public void setPname(String pname) {
		Pname = pname;
	}

	public String getAdr() {
		return adr;
	}

	public void setAdr(String adr) {
		this.adr = adr;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	
	
	

}
