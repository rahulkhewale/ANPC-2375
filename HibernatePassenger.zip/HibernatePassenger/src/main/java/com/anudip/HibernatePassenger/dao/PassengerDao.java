package com.anudip.HibernatePassenger.dao;

public interface PassengerDao {
	
public void getPassenger();
	
	public void addPassenger();
	
	public void updatePassenger();
	
	public void deletePassenger();

}
