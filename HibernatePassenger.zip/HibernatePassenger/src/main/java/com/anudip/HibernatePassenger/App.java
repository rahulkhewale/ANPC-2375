package com.anudip.HibernatePassenger;

import java.util.Scanner;

import com.anudip.HibernatePassenger.daoImpl.PassengerDaoImpl;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	PassengerDaoImpl passdao = new PassengerDaoImpl();
        char a;
        
        do {
        	Scanner sc = new Scanner(System.in);
        	System.out.println("------Passenger Management--------");
        	System.out.println("Enter your choice");
        	System.out.println("1.Read passenger \n 2.Add Passenger  \n 3.Upadate Passenger  \n 4.Delete Passenger \n 5.Exit");
        	int ch = sc.nextInt();
        	switch(ch) {
        	
        	case 1: passdao.getPassenger();
        	break;
        	
        	case 2: passdao.addPassenger();
        	break;
        	
        	case 3: passdao.updatePassenger();
        	break;
        	
        	case 4: passdao.deletePassenger();
        	break;
        	
        	case 5: System.exit(0);
        	break;
        	
        	default:
        		System.out.println("invalid entry");
        	}
        	System.out.println("Do you want to continue? Y/N");
        	a =sc.next().charAt(0);
        }while( a =='Y' || a == 'y');
        System.out.println("Thank you.....");
    }
}
