package com.anudip.HibernatePassenger.daoImpl;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.anudip.HibernatePassenger.config.HibernatePassengerUtil;
import com.anudip.HibernatePassenger.dao.PassengerDao;
import com.anudip.HibernatePassenger.entity.Passenger;



;

public class PassengerDaoImpl implements PassengerDao {
	
	Scanner sc = new Scanner(System.in);
	int x;

	public void getPassenger() {
		// TODO Auto-generated method stub
		
		try {
			Session session = HibernatePassengerUtil.getSessionFactory().openSession();
			System.out.println("Enter Passenger id");
			int i = sc.nextInt();
			Passenger cd =session.get(Passenger.class, i);
			System.out.println("-----Customer Details are------");
			System.out.println(cd.getPid()+" "+cd.getPname()+" "+cd.getAge()+" "+cd.getPhone()+" "+cd.getAdr());
		}catch(HibernateException e) {
			System.out.println(e);
		}
		
	}

	public void addPassenger() {
		// TODO Auto-generated method stub
		
		
		try {
			Session session = HibernatePassengerUtil.getSessionFactory().openSession();
			Transaction tx = session.beginTransaction();
			String name, add;
			int phone;
			
			System.out.print("Enter Passenger Name :");
			name = sc.nextLine();
			
			System.out.print("Enter Passenger Address :");
			add = sc.nextLine();
			
			System.out.println("Enter Passenger Age :");
			x = sc.nextInt();
			System.out.print("Enter Passenger Phone :");
			phone = sc.nextInt();
 			
			Passenger passenger = new Passenger();
			
			passenger.setPname(name);
			passenger.setAge(x);
			passenger.setAdr(add);
			passenger.setPhone(phone);
			
			session.save(passenger);
			tx.commit();
			System.out.println("* Added Successfully *");
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
		
		
		
	}

	public void updatePassenger() {
		// TODO Auto-generated method stub
		
		try {
			Session session = HibernatePassengerUtil.getSessionFactory().openSession();
			Transaction t = session.beginTransaction();
			System.out.println("Enter your Passenger id");
			int i = sc.nextInt();
			Passenger pass1 =session.get(Passenger.class, i);
			System.out.println("Enter update phone number");
			long p1 = sc.nextLong();
			pass1.setPhone(p1);
			session.update(pass1);
			t.commit();
			System.out.println("updated successfully");
		}catch(HibernateException e) {
			System.out.println(e);
		}
		
	}

	public void deletePassenger() {
		// TODO Auto-generated method stub
		
		try {
			Session session = HibernatePassengerUtil.getSessionFactory().openSession();
			Transaction t = session.beginTransaction();
			System.out.println("Enter your Passenger id");
			int i = sc.nextInt();
			Passenger pass2 =session.get(Passenger.class, i);
			session.delete(pass2);
			t.commit();
			System.out.println("Deleted successfully");
		}catch(HibernateException e) {
			System.out.println(e);
		}
		
	}

	
	
}
