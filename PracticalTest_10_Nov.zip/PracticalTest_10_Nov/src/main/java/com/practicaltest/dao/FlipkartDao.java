package com.practicaltest.dao;

public interface FlipkartDao {
	public void add_Customer();
	
	public void fetch_Customer();

}
