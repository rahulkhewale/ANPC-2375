package com.practicaltest.daoimpl;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.practicaltest.HibernateUtil;
import com.practicaltest.dao.FlipkartDao;
import com.practicaltest.entity.Customer;
import com.practicaltest.entity.Flipkart;




public class FlipkartDaoImpl implements FlipkartDao{
	
	Scanner sc = new Scanner(System.in);

	@Override
	public void add_Customer() {
		// TODO Auto-generated method stub
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			Transaction t = session.beginTransaction();
			
			
			Customer c1 = new Customer();
			c1.setCust_id(1011);
			c1.setCname("rahul");
			c1.setCemail("rahul@gmail.com");
			c1.setAddress("Chandrapur");
			c1.setMobile_Number("854256485");
			
			
			
			Flipkart f1 = new Flipkart();
			
			f1.setOrder_id(20154);
			f1.setPrice(500);
			f1.setProduct_Name("Book");
			f1.setDelivery_Charges(20);
			f1.setDelivery_Date("27/12/2022");
			
			
			
			
			session.save(c1);
			session.save(f1);
			
			t.commit();
			System.out.println("done");
			
		}catch (HibernateException e) {
			System.out.println(e);
		}
		
	}

	
	@Override
	public void fetch_Customer() {
		// TODO Auto-generated method stub
		
		try {
			try {
				Session session = HibernateUtil.getSessionFactory().openSession();
				System.out.println("Enter your customer id");
				int i = sc.nextInt();
				Customer c =session.get(Customer.class, i);
				System.out.println("-----Customer Details are------");
				System.out.println(c.getCust_id()+" "+c.getCname()+" "+c.getCemail()+" "+c.getMobile_Number()+" "+c.getAddress());
			}catch(HibernateException e) {
				System.out.println(e);
			}
			
		}catch (HibernateException e) {
			System.out.println(e);
		}
	}

}
