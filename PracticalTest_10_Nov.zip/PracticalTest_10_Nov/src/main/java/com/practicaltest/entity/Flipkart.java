package com.practicaltest.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Data;

@Data
@Entity

public class Flipkart {
	@Id
	private int Order_id;
	
	@Column(length = 30, nullable = false)
	private int price;
	
	@Column(length = 30, nullable = false)
	private String Product_Name;
	
	@Column(length = 30, nullable = false)
	private String Delivery_Date;
	
	@Column(length = 30, nullable = false)
	private int Delivery_Charges;

	public int getOrder_id() {
		return Order_id;
	}

	public void setOrder_id(int order_id) {
		Order_id = order_id;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getProduct_Name() {
		return Product_Name;
	}

	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}

	public String getDelivery_Date() {
		return Delivery_Date;
	}

	public void setDelivery_Date(String delivery_Date) {
		Delivery_Date = delivery_Date;
	}

	public int getDelivery_Charges() {
		return Delivery_Charges;
	}

	public void setDelivery_Charges(int delivery_Charges) {
		Delivery_Charges = delivery_Charges;
	}
	
	
	
	
	
}
