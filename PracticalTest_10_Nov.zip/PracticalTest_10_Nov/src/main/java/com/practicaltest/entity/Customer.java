package com.practicaltest.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity

public class Customer {
	
	@Id
	private int Cust_id;
	
	@Column(length = 30, nullable = false)
	private String Cname;
	
	@Column(length = 30, nullable = false)
	private String Cemail;
	
	@Column(length = 30, nullable = false)
	private String Mobile_Number;
	
	@Column(length = 10, nullable = false)
	private String address;

	public int getCust_id() {
		return Cust_id;
	}

	public void setCust_id(int cust_id) {
		Cust_id = cust_id;
	}

	public String getCname() {
		return Cname;
	}

	public void setCname(String cname) {
		Cname = cname;
	}

	public String getCemail() {
		return Cemail;
	}

	public void setCemail(String cemail) {
		Cemail = cemail;
	}

	public String getMobile_Number() {
		return Mobile_Number;
	}

	public void setMobile_Number(String mobile_Number) {
		Mobile_Number = mobile_Number;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
