package com.practicaltest;

import com.practicaltest.daoimpl.FlipkartDaoImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
      FlipkartDaoImpl fdao = new FlipkartDaoImpl();
//       fdao.add_Customer();
       fdao.fetch_Customer();
    }
}
